package com.example.lonemanegementapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class HomeActivity extends AppCompatActivity {

    private Button btn_education,btn_gold,btn_personal,btn_car,btn_business,btn_home;
    private ProgressDialog loadingBar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        btn_education = (Button) findViewById(R.id.btn_educationLoan);
        btn_business = (Button) findViewById(R.id.btn_businessLoan);
        btn_car = (Button) findViewById(R.id.btn_carLoan);
        btn_gold = (Button) findViewById(R.id.btn_goldLoan);
        btn_home = (Button) findViewById(R.id.btn_homeLoan);
        btn_personal = (Button) findViewById(R.id.btn_personalLoan);
        loadingBar = new ProgressDialog(this);

        btn_education.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(HomeActivity.this, "EDUCATION LOAN CLICKED...", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(HomeActivity.this, EducationLoanActivity.class);
                startActivity(intent);
            }
        });
        btn_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(HomeActivity.this, "HOME LOAN CLICKED...", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(HomeActivity.this, HomeLoanActivity.class);
                startActivity(intent);
            }
        });
        btn_car.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(HomeActivity.this, "CAR LOAN CLICKED...", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(HomeActivity.this, CarLoanActivity.class);
                startActivity(intent);
            }
        });
        btn_business.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(HomeActivity.this, "BUSINESS LOAN CLICKED...", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(HomeActivity.this, BusinessLoanActivity.class);
                startActivity(intent);
            }
        });
        btn_personal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(HomeActivity.this, "PERSONAL LOAN CLICKED...", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(HomeActivity.this, PersonalLoanActivity.class);
                startActivity(intent);
            }
        });
        btn_gold.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(HomeActivity.this, "GOLD LOAN CLICKED...", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(HomeActivity.this, GoldLoanActivity.class);
                startActivity(intent);
            }
        });
    }
}
