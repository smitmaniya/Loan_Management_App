package com.example.lonemanegementapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class BusinessLoanActivity extends AppCompatActivity {

    private Button loan_Apply1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_business_loan);

        loan_Apply1 = (Button) findViewById(R.id.businessLoan_ApplyBtn);

        loan_Apply1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BusinessLoanActivity.this,LoanDocumentActivity.class);
                startActivity(intent);
            }
        });


    }
}
