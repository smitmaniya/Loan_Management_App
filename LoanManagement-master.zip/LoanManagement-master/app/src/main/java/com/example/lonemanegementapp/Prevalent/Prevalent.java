package com.example.loanapp.Prevalent;

import com.example.loanapp.Model.Users;

public class Prevalent {

    private static Users currentOnlineUser;

    public static final String UserPhoneKey = "UserPhone";
    public static final String UserPasswordKey = "UserPassword";
}
