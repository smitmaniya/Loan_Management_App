package com.example.lonemanegementapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class PersonalLoanActivity extends AppCompatActivity {

    private Button loan_Apply6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personal_loan);

        loan_Apply6 = (Button) findViewById(R.id.personalLoan_ApplyBtn);

        loan_Apply6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PersonalLoanActivity.this,LoanDocumentActivity.class);
                startActivity(intent);
            }
        });
    }
}
