package com.example.lonemanegementapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class HomeLoanActivity extends AppCompatActivity {
    private Button loan_Apply5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_loan);

        loan_Apply5 = (Button) findViewById(R.id.homeLoan_ApplyBtn);

        loan_Apply5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeLoanActivity.this,LoanDocumentActivity.class);
                startActivity(intent);
            }
        });

    }
}
