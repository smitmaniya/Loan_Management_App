package com.example.lonemanegementapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.PatternMatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

public class LoanDocumentActivity extends AppCompatActivity {

    Button selectFile,upload,submitbtn;
    TextView fileNameNotification, emiTotal;
    ProgressDialog progressDialog;
    EditText amount, interestRate, duration;
    int a, b, c;
    float result;

    FirebaseDatabase database;
    FirebaseStorage storage;
    Uri pdfUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loan_document);

        database = FirebaseDatabase.getInstance();
        storage = FirebaseStorage.getInstance();

        selectFile = findViewById(R.id.selectfile_btn);
        upload = findViewById(R.id.upload_btn);
        submitbtn = findViewById(R.id.submit_btn);
        amount = findViewById(R.id.amountOfLoanTaker);
        interestRate = findViewById(R.id.interestOfLoanTaker);
        duration = findViewById(R.id.durationOfLoanTaker);
        emiTotal = findViewById(R.id.emiOfLoanTaker);
        fileNameNotification = findViewById(R.id.fileNameNotification);


        selectFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ContextCompat.checkSelfPermission(LoanDocumentActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE)
                        == PackageManager.PERMISSION_GRANTED) {
                    selectPdf();

                } else {
                    ActivityCompat.requestPermissions(LoanDocumentActivity.this,new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 9);
                }
            }
        });

        upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (pdfUri != null)
                uploadFile(pdfUri);

                else {
                    Toast.makeText(LoanDocumentActivity.this, "Select a file", Toast.LENGTH_SHORT).show();
                }

            }
        });

        submitbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                a = Integer.parseInt(amount.getText().toString().trim());
//                b = Integer.parseInt(interestRate.getText().toString().trim());
//                c = Integer.parseInt(duration.getText().toString().trim());
//                result = (a*b*c);
//                Log.e("tag","amount"+amount);
//                Log.e("tag","interestRate"+interestRate);
//                Log.e("tag","duration"+duration);
                Intent intent = new Intent(LoanDocumentActivity.this, GreetingActivity.class);
                startActivity(intent);
            }
        });

    }

    private void uploadFile(Uri pdfUri) {

        progressDialog = new ProgressDialog(this);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        progressDialog.setTitle("Uploading File...");
        progressDialog.setProgress(0);
        progressDialog.show();

        final String filename = System.currentTimeMillis()+"";
        StorageReference storageReference = storage.getReference();

        storageReference.child("Uploads").child(filename).putFile(pdfUri)
                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                        String url = taskSnapshot.getMetadata().getReference().getDownloadUrl().toString();

                        DatabaseReference reference = database.getReference();

                        reference.child(filename).setValue(url).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()){
                                    Toast.makeText(LoanDocumentActivity.this, "File successfully uploaded...", Toast.LENGTH_SHORT).show();
                                }
                                else {
                                    Toast.makeText(LoanDocumentActivity.this, "File is not successfully uploaded...", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });

                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {

                Toast.makeText(LoanDocumentActivity.this, "File is not successfully uploaded...", Toast.LENGTH_SHORT).show();

            }
        }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onProgress(@NonNull UploadTask.TaskSnapshot taskSnapshot) {

                int currentProgress = (int) (100*taskSnapshot.getBytesTransferred()/taskSnapshot.getTotalByteCount());
                progressDialog.setProgress(currentProgress);

            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == 9 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            selectPdf();
        }
        else {
            Toast.makeText(LoanDocumentActivity.this, "please provide permission...", Toast.LENGTH_SHORT).show();
        }
    }

    private void selectPdf() {

        Intent intent = new Intent();
        intent.setType("application/pdf");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, 86);

        }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 86 && resultCode == RESULT_OK && data != null) {
            pdfUri = data.getData();
            fileNameNotification.setText("A file is selected :"+ data.getData().getLastPathSegment());
        }
        else {
            Toast.makeText(LoanDocumentActivity.this, "Please select a file...", Toast.LENGTH_SHORT).show();
        }
    }



}

