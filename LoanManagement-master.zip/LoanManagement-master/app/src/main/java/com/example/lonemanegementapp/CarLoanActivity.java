package com.example.lonemanegementapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class CarLoanActivity extends AppCompatActivity {

    private Button loan_Apply4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_car_loan);


        loan_Apply4 = (Button) findViewById(R.id.carLoan_ApplyBtn);

        loan_Apply4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CarLoanActivity.this,LoanDocumentActivity.class);
                startActivity(intent);
            }
        });
    }
}
